
def reversed_dict(item):
    return {v: k for k, v in item.items()}
